from pyspark.sql import SparkSession
from pyspark.sql.functions import col, hash, abs, concat, lit, first, count, when

import re

spark = (SparkSession
         .builder
         .appName("veeva")
         .master("local[*]")
         .getOrCreate())

file_path_1 = "file:///C://Users//thanu//file1.csv"
file_path_2 = "file:///C://Users//thanu//file2.csv"

def clean_column_names(df):

    cleaned_df = df

    for column_name in df.columns:
        # Remove numbers and spaces from column names
        cleaned_col_name = re.sub(r'[0-9 ]', '', column_name)
        # Rename the column
        cleaned_df = cleaned_df.withColumnRenamed(column_name, cleaned_col_name)

    return cleaned_df

if __name__ == '__main__':

    file_df_1 = clean_column_names(spark.read.csv(file_path_1, header=True, inferSchema=True)) # 363755, 353897
    file_df_2 = clean_column_names(spark.read.csv(file_path_2, header=True, inferSchema=True)) # 53804, 53268

    # create id's based on address and adding row_from that indicate where the file is from
    df_withIds_1 = (file_df_1
                    .withColumn("id",abs(hash(concat(col("address"), lit(", "),col("city"), lit(", "), col("zip")))))
                    .withColumn("row_from", lit("file_1"))).dropDuplicates()
    df_withIds_2 = (file_df_2
                    .withColumn("id", abs(hash(concat(col("address"), lit(", "), col("city"), lit(", "), col("zip")))))
                    .withColumn("row_from", lit("file_2"))).dropDuplicates()

    # combine DF result 407165 after agg --> 242411 explain why dropDuplicates is not needed
    combined_df = (df_withIds_1.union(df_withIds_2).groupBy("id")
                   .agg(first("name").alias("name"),
                        count("id").alias("counts"),
                        first("address").alias("address"),
                        first("city").alias("city"),
                        first("zip").alias("zip")))

    #print(combined_df.count())

    result = (combined_df.alias("c")
              .join(df_withIds_1.alias("df1"), col("c.id") == col("df1.id"), "left")
              .join(df_withIds_2.alias("df2"), col("c.id") == col("df2.id"), "left")
              .withColumn("flag_1", when(col("df1.row_from") == "file_1", True).otherwise(False))
              .withColumn("flag_2", when(col("df2.row_from") == "file_2", True).otherwise(False))
              .select("c.id", "c.name", "c.counts", "c.address", "c.city", "c.zip", "df1.row_from", "df2.row_from", "flag_1", "flag_2"))

    print(result.count())
    print(result.dropDuplicates().count())

    print(result.dropDuplicates().orderBy("counts", ascending=False).show(truncate=False))


    # print(combined_df.orderBy("id", ascending=True).show(truncate=False))

    # Stop the Spark session
    spark.stop()